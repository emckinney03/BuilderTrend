# Generate docs using jsDoc
## Code used in our project
This is our Capstone (BuilderTrend) Home Page 5/9/2023